"""
KURNOOL CROP DEMAND PREDICTION - BASELINE VIABILITY PIPELINE
Datasets: ICRISAT (Crop, Price, Fertiliser, Rainfall, Landuse, Area) +
          Temperature + FAOSTAT (Import/Export) + CPI
Model: Random Forest + XGBoost
Target: Crop Yield (proxy for demand/supply pressure)
"""

import pandas as pd
import numpy as np
import zipfile
import warnings
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import cross_val_score, KFold
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import xgboost as xgb

warnings.filterwarnings('ignore')

# ============================================================
# STEP 1: LOAD ALL DATASETS
# ============================================================
print("=" * 60)
print("STEP 1: LOADING DATASETS")
print("=" * 60)

BASE = "/mnt/user-data/uploads/"

# 1A. Crop data (area, production, yield per crop) - BACKBONE
crop = pd.read_csv(BASE + "ICRISAT-Crop_data.csv")
print(f"[OK] Crop data: {crop.shape} | Years: {crop['Year'].min()}-{crop['Year'].max()}")

# 1B. Prices - harvest price per crop (has -1 for missing)
price = pd.read_csv(BASE + "ICRISAT-Price.csv")
price.replace(-1, np.nan, inplace=True)  # -1 = missing in ICRISAT convention
print(f"[OK] Price data: {price.shape} | Years: {price['Year'].min()}-{price['Year'].max()}")

# 1C. Fertilisers - N, P, K consumption
fert = pd.read_csv(BASE + "ICRISAT-Fertilisers.csv")
print(f"[OK] Fertiliser data: {fert.shape} | Years: {fert['Year'].min()}-{fert['Year'].max()}")

# 1D. Rainfall (ICRISAT) - monthly, 1990-2020
rain_icrisat = pd.read_csv(BASE + "ICRISAT-Rainfall.csv")
print(f"[OK] ICRISAT Rainfall: {rain_icrisat.shape} | Years: {rain_icrisat['Year'].min()}-{rain_icrisat['Year'].max()}")

# 1E. Landuse - net/gross cropped area, cropping intensity
landuse = pd.read_csv(BASE + "ICRISAT-land-different.csv")
print(f"[OK] Landuse: {landuse.shape} | Years: {landuse['Year'].min()}-{landuse['Year'].max()}")

# 1F. Irrigated area per crop
area_irr = pd.read_csv(BASE + "ICRISAT-Area.csv")
print(f"[OK] Irrigated Area: {area_irr.shape} | Years: {area_irr['Year'].min()}-{area_irr['Year'].max()}")

# 1G. Temperature (monthly, Kurnool station, 1969-2020)
temp = pd.read_csv(BASE + "important_temperature_data.csv")
temp['date'] = pd.to_datetime(temp['date'])
temp['Year'] = temp['date'].dt.year
print(f"[OK] Temperature: {temp.shape} | Years: {temp['Year'].min()}-{temp['Year'].max()}")

# 1H. Rainfall_again (daily, 2009-2023) - will aggregate to annual
rain2 = pd.read_csv(BASE + "rainfall_again.csv")
rain2['date'] = pd.to_datetime(rain2['date'])
rain2['Year'] = rain2['date'].dt.year
print(f"[OK] Rainfall (daily): {rain2.shape} | Years: {rain2['Year'].min()}-{rain2['Year'].max()}")

# 1I. FAOSTAT Import/Export (India-level, 1961-2024)
fao = pd.read_csv(BASE + "FAOSTAT-IMPORTEXPORT.csv")
print(f"[OK] FAOSTAT: {fao.shape} | Years: {fao['Year'].min()}-{fao['Year'].max()}")

# 1J. CPI - Crop Production Index (India, 1960-2022)
with zipfile.ZipFile(BASE + "CPI.zip") as z:
    with z.open("API_AG.PRD.CROP.XD_DS2_en_csv_v2_11657.csv") as f:
        cpi_raw = pd.read_csv(f, skiprows=4)
cpi_india = cpi_raw[cpi_raw['Country Name'] == 'India'].copy()
year_cols = [c for c in cpi_india.columns if c.isdigit()]
cpi = cpi_india[year_cols].T.reset_index()
cpi.columns = ['Year', 'CPI']
cpi['Year'] = cpi['Year'].astype(int)
cpi['CPI'] = pd.to_numeric(cpi['CPI'], errors='coerce')
cpi = cpi.dropna()
print(f"[OK] CPI: {cpi.shape} | Years: {cpi['Year'].min()}-{cpi['Year'].max()}")

# ============================================================
# STEP 2: FEATURE ENGINEERING
# ============================================================
print("\n" + "=" * 60)
print("STEP 2: FEATURE ENGINEERING")
print("=" * 60)

# --- 2A. TEMPERATURE: pivot min/max, compute annual mean ---
# WHY: Temp affects crop stress, evapotranspiration, pest cycles
temp_min = temp[temp['parameter'] == 'minimum temperature'].groupby('Year')['average_temperature'].mean().reset_index()
temp_max = temp[temp['parameter'] == 'maximum temperature'].groupby('Year')['average_temperature'].mean().reset_index()
temp_min.columns = ['Year', 'avg_min_temp_c']
temp_max.columns = ['Year', 'avg_max_temp_c']
temp_annual = temp_min.merge(temp_max, on='Year')
temp_annual['temp_range'] = temp_annual['avg_max_temp_c'] - temp_annual['avg_min_temp_c']
print(f"[FE] Temperature annual features: {temp_annual.shape}")

# --- 2B. RAINFALL: use ICRISAT monthly → compute kharif/rabi season rainfall ---
# WHY: Kharif (Jun-Sep) and Rabi (Oct-Feb) rainfall matter differently for different crops
# Kharif rainfall → directly affects Sorghum, Groundnut, Pearl Millet yields
# Rabi rainfall → affects Chickpea, Wheat, Pigeonpea

kharif_months = ['JUNE RAINFALL (Millimeters)', 'JULY RAINFALL (Millimeters)',
                 'AUGUST RAINFALL (Millimeters)', 'SEPTEMBER RAINFALL (Millimeters)']
rabi_months = ['OCTOBER RAINFALL (Millimeters)', 'NOVEMBER RAINFALL (Millimeters)',
               'DECEMBER RAINFALL (Millimeters)', 'JANUARY RAINFALL (Millimeters)',
               'FEBRUARY RAINFALL (Millimeters)']

rain_fe = rain_icrisat[['Year', 'ANNUAL RAINFALL (Millimeters)']].copy()
rain_fe.columns = ['Year', 'annual_rainfall_mm']
rain_fe['kharif_rainfall_mm'] = rain_icrisat[kharif_months].sum(axis=1).values
rain_fe['rabi_rainfall_mm'] = rain_icrisat[rabi_months].sum(axis=1).values

# Rainfall lag (t-1 year): lagged rainfall affects yield with a delay
# WHY: Soil moisture recharge from previous kharif affects rabi crops
rain_fe['kharif_rainfall_lag1'] = rain_fe['kharif_rainfall_mm'].shift(1)
rain_fe['annual_rainfall_lag1'] = rain_fe['annual_rainfall_mm'].shift(1)
print(f"[FE] Rainfall seasonal features: {rain_fe.shape}")

# --- 2C. FERTILISER: NPK ratio + total intensity ---
# WHY: N/P/K ratio is a soil health signal; total per ha reflects input investment
fert_fe = fert[['Year', 'NITROGEN CONSUMPTION (tons)', 'PHOSPHATE CONSUMPTION (tons)',
                 'POTASH CONSUMPTION (tons)', 'TOTAL CONSUMPTION (tons)',
                 'TOTAL PER HA OF GCA (Kg per ha)']].copy()
fert_fe.columns = ['Year', 'N_consumption_tons', 'P_consumption_tons',
                   'K_consumption_tons', 'total_fert_tons', 'fert_per_ha_gca']

# NPK ratio features - imbalanced NPK = nutrient stress
fert_fe['N_P_ratio'] = fert_fe['N_consumption_tons'] / (fert_fe['P_consumption_tons'] + 1)
fert_fe['N_K_ratio'] = fert_fe['N_consumption_tons'] / (fert_fe['K_consumption_tons'] + 1)

# Fertiliser trend (3-year rolling mean) - smooths out data entry anomalies
fert_fe['fert_rolling3'] = fert_fe['fert_per_ha_gca'].rolling(3).mean()
print(f"[FE] Fertiliser features: {fert_fe.shape}")

# --- 2D. LANDUSE: cropping intensity, fallow ratio ---
# WHY: Gross/Net Cropped Area ratio = cropping intensity, fallow area = unused land signal
land_fe = landuse[['Year', 'NET CROPPED AREA (1000 ha)', 'GROSS CROPPED AREA (1000 ha)',
                    'CURRENT FALLOW AREA (1000 ha)', 'CROPING INTENSITY (Percent)']].copy()
land_fe.columns = ['Year', 'net_cropped_area', 'gross_cropped_area', 'fallow_area', 'cropping_intensity']
land_fe['fallow_ratio'] = land_fe['fallow_area'] / (land_fe['net_cropped_area'] + 1)
print(f"[FE] Landuse features: {land_fe.shape}")

# --- 2E. FAOSTAT: India-level import pressure per crop ---
# WHY: When India imports heavily, domestic price drops (excess supply)
# When exports rise, domestic supply tightens → price rises
fao_pivot = fao.pivot_table(index=['Year', 'Item'], columns='Element', values='Value').reset_index()
fao_pivot.columns.name = None
fao_pivot = fao_pivot.rename(columns={
    'Import quantity': 'import_qty_tons',
    'Import value': 'import_val_1000usd',
    'Export quantity': 'export_qty_tons',
    'Export value': 'export_val_1000usd'
})

# Net trade balance: positive = net exporter (supply surplus), negative = net importer
fao_pivot['net_export_qty'] = fao_pivot.get('export_qty_tons', 0).fillna(0) - fao_pivot.get('import_qty_tons', 0).fillna(0)

# Map FAOSTAT crop names to ICRISAT crop names
crop_map = {
    'Rice': 'RICE', 'Wheat': 'WHEAT', 'Sorghum': 'SORGHUM',
    'Maize (corn)': 'MAIZE', 'Millet': 'PEARL MILLET',
    'Chick peas, dry': 'CHICKPEA', 'Pigeon peas, dry': 'PIGEONPEA',
    'Groundnuts, shelled': 'GROUNDNUT', 'Cotton seed': 'COTTON',
    'Sugar cane': 'SUGARCANE', 'Linseed': 'LINSEED',
    'Castor oil seeds': 'CASTOR', 'Barley': 'BARLEY',
    'Mustard seed': 'RAPESEED AND MUSTARD', 'Safflower seed': 'SAFFLOWER',
    'Sunflower seed': 'SUNFLOWER', 'Soya beans': 'SOYABEAN',
}
fao_pivot['crop_std'] = fao_pivot['Item'].map(crop_map)
print(f"[FE] FAOSTAT import/export features created")

# --- 2F. CPI: India crop production index - macro signal ---
# WHY: National crop production trend affects Kurnool price via market integration
cpi_fe = cpi.copy()
cpi_fe['cpi_lag1'] = cpi_fe['CPI'].shift(1)
cpi_fe['cpi_yoy_change'] = cpi_fe['CPI'].pct_change() * 100  # year-over-year % change
print(f"[FE] CPI features: {cpi_fe.shape}")

# --- 2G. CYCLICAL TIME ENCODING ---
# WHY: Year as integer is wrong - model doesn't know 1975 is between 1974 and 1976 cyclically
# Use decade encoding and linear trend
# (Full sine/cosine encoding more relevant for monthly data; for annual, use trend + decade)

# ============================================================
# STEP 3: MELT CROP DATA TO LONG FORMAT
# ============================================================
print("\n" + "=" * 60)
print("STEP 3: RESHAPE CROP DATA (WIDE → LONG FORMAT)")
print("=" * 60)

# WHY: ICRISAT stores one row per year, one column per crop
# For ML: we want one row per (year, crop) - this is the melting/pivoting technique from notes
# Each row = one observation = (Year, Crop, Area, Production, Yield, IrrigatedArea, Price)

crop_cols = {}
for col in crop.columns:
    for crop_name in ['RICE', 'WHEAT', 'SORGHUM', 'PEARL MILLET', 'MAIZE',
                       'CHICKPEA', 'PIGEONPEA', 'GROUNDNUT', 'COTTON', 'SUGARCANE',
                       'CASTOR', 'SUNFLOWER', 'FINGER MILLET']:
        if col.startswith(crop_name) and 'KHARIF' not in col and 'RABI' not in col:
            metric = col.replace(crop_name, '').strip()
            if crop_name not in crop_cols:
                crop_cols[crop_name] = {}
            crop_cols[crop_name][metric] = col

long_rows = []
for crop_name, metrics in crop_cols.items():
    if 'AREA (1000 ha)' in metrics and 'PRODUCTION (1000 tons)' in metrics and 'YIELD (Kg per ha)' in metrics:
        tmp = crop[['Year', metrics['AREA (1000 ha)'], metrics['PRODUCTION (1000 tons)'], metrics['YIELD (Kg per ha)']]].copy()
        tmp.columns = ['Year', 'area_1000ha', 'production_1000tons', 'yield_kg_ha']
        tmp['crop'] = crop_name
        long_rows.append(tmp)

df_long = pd.concat(long_rows, ignore_index=True)
df_long = df_long[df_long['area_1000ha'] > 0].copy()  # drop crops not grown in Kurnool
print(f"Long format: {df_long.shape} | Crops: {df_long['crop'].unique()}")

# Add price per crop
price_long = []
price_col_map = {
    'PADDY': 'RICE', 'SORGHUM': 'SORGHUM', 'PEARL MILLET': 'PEARL MILLET',
    'CHICKPEA': 'CHICKPEA', 'PIGEONPEA': 'PIGEONPEA', 'GROUNDNUT': 'GROUNDNUT',
    'COTTON KAPAS': 'COTTON', 'MAIZE': 'MAIZE',
}
for price_key, crop_name in price_col_map.items():
    pcol = [c for c in price.columns if price_key in c and 'PRICE' in c]
    if pcol:
        tmp = price[['Year', pcol[0]]].copy()
        tmp.columns = ['Year', 'harvest_price_rs_quintal']
        tmp['crop'] = crop_name
        price_long.append(tmp)

price_df = pd.concat(price_long, ignore_index=True)
df_long = df_long.merge(price_df, on=['Year', 'crop'], how='left')
print(f"After price merge: {df_long.shape}")

# ============================================================
# STEP 4: MASTER MERGE - ALL FEATURES INTO ONE DATAFRAME
# ============================================================
print("\n" + "=" * 60)
print("STEP 4: MASTER MERGE")
print("=" * 60)

# All environmental and macro features are year-level (not crop-level)
# So we merge on Year - each crop row gets the same env features for that year

df = df_long.copy()
df = df.merge(temp_annual, on='Year', how='left')
df = df.merge(rain_fe, on='Year', how='left')
df = df.merge(fert_fe, on='Year', how='left')
df = df.merge(land_fe, on='Year', how='left')
df = df.merge(cpi_fe, on='Year', how='left')

# FAOSTAT: add import pressure per crop (India-level signal)
fao_merge = fao_pivot[['Year', 'crop_std', 'net_export_qty']].dropna(subset=['crop_std'])
df = df.merge(fao_merge, left_on=['Year', 'crop'], right_on=['Year', 'crop_std'], how='left')
df.drop(columns=['crop_std'], inplace=True, errors='ignore')

# Crop one-hot encoding (RF/XGBoost need numeric crop labels)
df['crop_code'] = df['crop'].astype('category').cat.codes

# Year trend feature (linear)
df['year_trend'] = df['Year'] - df['Year'].min()

# Yield lag (previous year's yield for same crop - strong autoregressive signal)
df = df.sort_values(['crop', 'Year'])
df['yield_lag1'] = df.groupby('crop')['yield_kg_ha'].shift(1)
df['yield_lag2'] = df.groupby('crop')['yield_kg_ha'].shift(2)
df['yield_rolling3'] = df.groupby('crop')['yield_kg_ha'].transform(
    lambda x: x.shift(1).rolling(3).mean()
)

# Price lag
df['price_lag1'] = df.groupby('crop')['harvest_price_rs_quintal'].shift(1)

# Area change YoY (farmer planting decision signal)
df['area_yoy_change'] = df.groupby('crop')['area_1000ha'].pct_change() * 100

print(f"Master dataframe: {df.shape}")
print(f"Year range: {df['Year'].min()}-{df['Year'].max()}")
print(f"Crops: {df['crop'].unique()}")
print(f"\nFeature columns:\n{[c for c in df.columns if c not in ['Year','crop','yield_kg_ha','production_1000tons']]}")

# ============================================================
# STEP 5: PREPARE FOR MODELLING
# ============================================================
print("\n" + "=" * 60)
print("STEP 5: PREPARE TRAIN/TEST DATA")
print("=" * 60)

TARGET = 'yield_kg_ha'

FEATURES = [
    # Crop identity
    'crop_code',
    # Supply-side
    'area_1000ha', 'area_yoy_change',
    # Yield history (autoregressive)
    'yield_lag1', 'yield_lag2', 'yield_rolling3',
    # Price
    'price_lag1',
    # Fertiliser
    'N_consumption_tons', 'P_consumption_tons', 'K_consumption_tons',
    'fert_per_ha_gca', 'N_P_ratio', 'fert_rolling3',
    # Weather
    'avg_min_temp_c', 'avg_max_temp_c', 'temp_range',
    'annual_rainfall_mm', 'kharif_rainfall_mm', 'rabi_rainfall_mm',
    'kharif_rainfall_lag1', 'annual_rainfall_lag1',
    # Landuse
    'net_cropped_area', 'cropping_intensity', 'fallow_ratio',
    # Macro
    'CPI', 'cpi_lag1', 'cpi_yoy_change',
    'net_export_qty',
    # Time
    'year_trend',
]

df_model = df[FEATURES + [TARGET, 'Year', 'crop']].copy()
df_model = df_model.dropna(subset=[TARGET])

# Impute remaining missing values (median imputation)
# WHY: XGBoost can handle NaN but RF cannot; impute for fair comparison
imputer = SimpleImputer(strategy='median')
X = df_model[FEATURES].copy()
y = df_model[TARGET].copy()

X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=FEATURES)

print(f"Final modelling dataset: {X_imputed.shape}")
print(f"Target distribution: min={y.min():.0f}, mean={y.mean():.0f}, max={y.max():.0f} kg/ha")
print(f"Missing in target: {y.isnull().sum()}")

# Temporal train/test split (NOT random split - time series rule)
# WHY: Random split leaks future data into training (data leakage)
# Always split time series by time - train on past, test on future
split_year = 2010
train_mask = df_model['Year'] <= split_year
test_mask = df_model['Year'] > split_year

X_train, X_test = X_imputed[train_mask], X_imputed[test_mask]
y_train, y_test = y[train_mask], y[test_mask]

print(f"\nTrain: {X_train.shape} (Years ≤ {split_year})")
print(f"Test:  {X_test.shape}  (Years > {split_year})")

# ============================================================
# STEP 6: RANDOM FOREST
# ============================================================
print("\n" + "=" * 60)
print("STEP 6: RANDOM FOREST")
print("=" * 60)

rf = RandomForestRegressor(
    n_estimators=200,
    max_depth=8,
    min_samples_leaf=3,
    random_state=42,
    n_jobs=-1
)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)

rf_r2   = r2_score(y_test, rf_pred)
rf_mae  = mean_absolute_error(y_test, rf_pred)
rf_rmse = np.sqrt(mean_squared_error(y_test, rf_pred))

print(f"Random Forest Results:")
print(f"  R²   = {rf_r2:.4f}  (how much variance explained; >0.7 is good)")
print(f"  MAE  = {rf_mae:.1f} kg/ha (average error in yield prediction)")
print(f"  RMSE = {rf_rmse:.1f} kg/ha")

# Feature importance
rf_importance = pd.DataFrame({
    'feature': FEATURES,
    'importance': rf.feature_importances_
}).sort_values('importance', ascending=False)

print(f"\nTop 10 most important features (RF):")
print(rf_importance.head(10).to_string(index=False))

# ============================================================
# STEP 7: XGBOOST
# ============================================================
print("\n" + "=" * 60)
print("STEP 7: XGBOOST")
print("=" * 60)

xgb_model = xgb.XGBRegressor(
    n_estimators=300,
    max_depth=5,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    verbosity=0
)
xgb_model.fit(X_train, y_train,
              eval_set=[(X_test, y_test)],
              verbose=False)
xgb_pred = xgb_model.predict(X_test)

xgb_r2   = r2_score(y_test, xgb_pred)
xgb_mae  = mean_absolute_error(y_test, xgb_pred)
xgb_rmse = np.sqrt(mean_squared_error(y_test, xgb_pred))

print(f"XGBoost Results:")
print(f"  R²   = {xgb_r2:.4f}")
print(f"  MAE  = {xgb_mae:.1f} kg/ha")
print(f"  RMSE = {xgb_rmse:.1f} kg/ha")

xgb_importance = pd.DataFrame({
    'feature': FEATURES,
    'importance': xgb_model.feature_importances_
}).sort_values('importance', ascending=False)

print(f"\nTop 10 most important features (XGBoost):")
print(xgb_importance.head(10).to_string(index=False))

# ============================================================
# STEP 8: VISUALISATIONS
# ============================================================
print("\n" + "=" * 60)
print("STEP 8: GENERATING PLOTS")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(18, 12))
fig.suptitle('Kurnool Crop Yield Prediction - Model Viability Analysis', fontsize=14, fontweight='bold')

# Plot 1: RF Predicted vs Actual
ax = axes[0, 0]
ax.scatter(y_test, rf_pred, alpha=0.6, color='steelblue', s=30)
lim = [min(y_test.min(), rf_pred.min()), max(y_test.max(), rf_pred.max())]
ax.plot(lim, lim, 'r--', lw=1.5, label='Perfect prediction')
ax.set_xlabel('Actual Yield (kg/ha)')
ax.set_ylabel('Predicted Yield (kg/ha)')
ax.set_title(f'Random Forest\nR²={rf_r2:.3f} | MAE={rf_mae:.0f} kg/ha')
ax.legend()

# Plot 2: XGBoost Predicted vs Actual
ax = axes[0, 1]
ax.scatter(y_test, xgb_pred, alpha=0.6, color='darkorange', s=30)
ax.plot(lim, lim, 'r--', lw=1.5, label='Perfect prediction')
ax.set_xlabel('Actual Yield (kg/ha)')
ax.set_ylabel('Predicted Yield (kg/ha)')
ax.set_title(f'XGBoost\nR²={xgb_r2:.3f} | MAE={xgb_mae:.0f} kg/ha')
ax.legend()

# Plot 3: Model comparison bar chart
ax = axes[0, 2]
models = ['Random Forest', 'XGBoost']
r2s = [rf_r2, xgb_r2]
colors = ['steelblue', 'darkorange']
bars = ax.bar(models, r2s, color=colors, width=0.4)
ax.set_ylabel('R² Score')
ax.set_title('Model Comparison (R²)')
ax.set_ylim(0, 1)
ax.axhline(y=0.7, color='green', linestyle='--', alpha=0.7, label='Good threshold (0.7)')
ax.legend()
for bar, val in zip(bars, r2s):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
            f'{val:.3f}', ha='center', fontsize=11, fontweight='bold')

# Plot 4: RF Feature Importance (Top 12)
ax = axes[1, 0]
top12 = rf_importance.head(12)
colors_fi = ['#d62728' if i < 3 else '#1f77b4' for i in range(12)]
ax.barh(range(len(top12)), top12['importance'].values, color=colors_fi)
ax.set_yticks(range(len(top12)))
ax.set_yticklabels(top12['feature'].values, fontsize=8)
ax.invert_yaxis()
ax.set_xlabel('Importance Score')
ax.set_title('RF Feature Importance (Top 12)\nRed = Top 3 drivers')

# Plot 5: XGBoost Feature Importance (Top 12)
ax = axes[1, 1]
top12x = xgb_importance.head(12)
ax.barh(range(len(top12x)), top12x['importance'].values, color='darkorange', alpha=0.8)
ax.set_yticks(range(len(top12x)))
ax.set_yticklabels(top12x['feature'].values, fontsize=8)
ax.invert_yaxis()
ax.set_xlabel('Importance Score')
ax.set_title('XGBoost Feature Importance (Top 12)')

# Plot 6: Yield trend for top 3 crops in Kurnool
ax = axes[1, 2]
top_crops = df_long.groupby('crop')['production_1000tons'].sum().nlargest(4).index
for crop_name in top_crops:
    tmp = df_long[df_long['crop'] == crop_name].sort_values('Year')
    ax.plot(tmp['Year'], tmp['yield_kg_ha'], marker='o', markersize=3,
            label=crop_name, alpha=0.8)
ax.set_xlabel('Year')
ax.set_ylabel('Yield (kg/ha)')
ax.set_title('Yield Trends - Top Crops in Kurnool')
ax.legend(fontsize=7)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/kurnool_viability_analysis.png', dpi=150, bbox_inches='tight')
print("[OK] Plot saved: kurnool_viability_analysis.png")

# ============================================================
# STEP 9: FINAL DATA AUDIT REPORT
# ============================================================
print("\n" + "=" * 60)
print("STEP 9: FINAL DATA AUDIT REPORT")
print("=" * 60)

print("""
DATASET AUDIT FOR KURNOOL
==========================================================

DATASETS TO USE (KEEP):
---------------------------------------------------------
1. ICRISAT-Crop_data.csv       [EXCELLENT]
   - 52 years (1966-2017), 26 crops, area/production/yield
   - Zero missing values
   - BACKBONE of the model

2. ICRISAT-Fertilisers.csv     [EXCELLENT]
   - 52 years, N/P/K consumption, fertiliser intensity per ha
   - Strong agronomic signal for yield prediction

3. ICRISAT-Price.csv           [GOOD WITH CAVEATS]
   - 51 years harvest prices
   - PROBLEM: Many crops have 50-100% missing (-1) values
     Usable: Paddy(2%), Sorghum(2%), Pearl Millet(0%),
             Chickpea(14%), Pigeonpea(2%), Groundnut(2%),
             Cotton(2%)
   - Drop: Rice(100%), Wheat(94%), Barley(100%), Linseed(100%)
   - Use as feature only for crops with <20% missing

4. important_temperature_data.csv  [EXCELLENT]
   - 1969-2020, monthly min/max temps, zero missing
   - Kurnool specific station data (43213)
   - Aggregate to annual avg min/max/range for yearly model

5. ICRISAT-Rainfall.csv        [GOOD]
   - 1990-2020, monthly rainfall, Kurnool specific
   - Only 31 years - shorter than crop data (1966-2017)
   - Use it: covers the most critical overlap window

6. ICRISAT-land-different.csv  [GOOD]
   - 1966-2020, net/gross cropped area, fallow, cropping intensity
   - Useful for land pressure features

7. FAOSTAT-IMPORTEXPORT.csv    [GOOD - MACRO SIGNAL]
   - 1961-2024, India-level import/export for 31 crop types
   - Not Kurnool specific, but import pressure affects local prices
   - Good for net_export_qty feature

8. CPI.zip (World Bank)        [GOOD - MACRO SIGNAL]
   - India Crop Production Index, 1960-2022
   - National productivity trend signal
   - Useful as a macro feature alongside local data

DATASETS TO SKIP OR USE CAREFULLY:
---------------------------------------------------------
9. rainfall_again.csv          [PARTIAL - LIMITED YEARS]
   - Daily rainfall, 2009-2023 only (15 years)
   - Good for recent data only; does not cover the 1966-2017 core window
   - Use only to supplement ICRISAT rainfall for 2018-2020

10. WORLD_import_export_data.xlsx  [SKIP]
    - World Bank commodity price FORECASTS (not historical data)
    - Not crop-level, not India-specific enough
    - Messy header structure, needs heavy cleaning for minimal gain

11. dataset_with_good_features.zip [PARTIAL]
    - crop_yield.csv: State-level (not district), 1997-2020
    - state_soil_data.csv: One soil NPK per state (too coarse)
    - state_weather_data: State-level, not Kurnool-specific
    - Andhra Pradesh soil pH=6.8 from state_soil_data CAN be used
      as a constant feature (soil type doesn't change year to year)
    
12. ICRISAT-Area.csv           [REDUNDANT]
    - Irrigated area per crop
    - Already partially captured in crop_data (area) and landuse
    - Can add irrigated area ratio as a feature but low priority

WHAT IS MISSING (What to get next):
---------------------------------------------------------
A. MSP (Minimum Support Price) data - NOT in any dataset
   - Critical for farmer sell/hold decision modelling
   - Source: CACP (cacp.dacnet.nic.in) - manually downloadable
   - Available from 1975 onwards for major crops

B. Soil data for Kurnool specifically
   - ICRISAT biophysical link has this: data.icrisat.org/dld/src/biophysical.html
   - State_soil_data gives only state average - too coarse
   - Need: N, P, K, pH, organic matter at district level

C. Mandi/Market price data (weekly/monthly)
   - ICRISAT gives annual harvest price - good for yearly model
   - For LSTM later: Agmarknet weekly prices needed
   - Current data is enough for RF/XGBoost baseline

D. Groundwater / Irrigation source data
   - ICRISAT-Area.csv has irrigated area but not source
   - Affects yield especially in drought years

WHAT THE MODELS TELL US:
---------------------------------------------------------
- If R² > 0.70: Data is viable, features are predictive
- If R² 0.50-0.70: Data is partially useful, more features needed
- If R² < 0.50: Data gaps too large, missing variables dominate

The most likely top features based on domain knowledge:
  yield_lag1 (previous year yield) → strongest autoregressive signal
  kharif_rainfall_mm → primary driver for Kharif crops
  fert_per_ha_gca → input investment signal
  crop_code → crop identity captures baseline yield level
  year_trend → long-term technology adoption trend
""")

print("=" * 60)
print("PIPELINE COMPLETE")
print("=" * 60)
